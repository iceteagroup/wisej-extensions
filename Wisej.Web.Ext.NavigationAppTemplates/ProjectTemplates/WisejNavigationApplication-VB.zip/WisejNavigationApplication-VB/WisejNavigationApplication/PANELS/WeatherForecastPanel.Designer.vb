﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WeatherForecastPanel
    Inherits Wisej.Web.UserControl

    'WeatherForecastPanel overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Wisej Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Wisej Designer
    'It can be modified using the Wisej Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.buttonClickMe = New Wisej.Web.Button()
        Me.comboBoxNumbeFetch = New Wisej.Web.ComboBox()
        Me.label2 = New Wisej.Web.Label()
        Me.label1 = New Wisej.Web.Label()
        Me.dataGridViewData = New Wisej.Web.DataGridView()
        CType(Me.dataGridViewData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'buttonClickMe
        '
        Me.buttonClickMe.Location = New System.Drawing.Point(171, 136)
        Me.buttonClickMe.Name = "buttonClickMe"
        Me.buttonClickMe.Size = New System.Drawing.Size(119, 30)
        Me.buttonClickMe.TabIndex = 10
        Me.buttonClickMe.Text = "Click me"
        '
        'comboBoxNumbeFetch
        '
        Me.comboBoxNumbeFetch.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList
        Me.comboBoxNumbeFetch.Items.AddRange(New Object() {"5", "100", "1000", "10000", "100000", "1000000"})
        Me.comboBoxNumbeFetch.Location = New System.Drawing.Point(17, 136)
        Me.comboBoxNumbeFetch.Name = "comboBoxNumbeFetch"
        Me.comboBoxNumbeFetch.Size = New System.Drawing.Size(120, 30)
        Me.comboBoxNumbeFetch.TabIndex = 9
        Me.comboBoxNumbeFetch.Text = "5"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(17, 90)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(345, 18)
        Me.label2.TabIndex = 8
        Me.label2.Text = "This component demonstrates fetching data from a service."
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("windowTitle", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.label1.Location = New System.Drawing.Point(17, 16)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(327, 54)
        Me.label1.TabIndex = 7
        Me.label1.Text = "Weather forecast"
        '
        'dataGridViewData
        '
        Me.dataGridViewData.Anchor = CType((((Wisej.Web.AnchorStyles.Top Or Wisej.Web.AnchorStyles.Bottom) _
            Or Wisej.Web.AnchorStyles.Left) _
            Or Wisej.Web.AnchorStyles.Right), Wisej.Web.AnchorStyles)
        Me.dataGridViewData.AutoSizeColumnsMode = Wisej.Web.DataGridViewAutoSizeColumnsMode.Fill
        Me.dataGridViewData.BorderStyle = Wisej.Web.BorderStyle.None
        Me.dataGridViewData.CellBorderStyle = Wisej.Web.DataGridViewCellBorderStyle.Horizontal
        Me.dataGridViewData.ColumnHeadersHeightSizeMode = Wisej.Web.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dataGridViewData.DefaultRowHeight = 42
        Me.dataGridViewData.DefaultSortMode = Wisej.Web.DataGridViewColumnsSortMode.NotSortable
        Me.dataGridViewData.Location = New System.Drawing.Point(17, 186)
        Me.dataGridViewData.Margin = New Wisej.Web.Padding(3, 3, 3, 15)
        Me.dataGridViewData.Name = "dataGridViewData"
        Me.dataGridViewData.RowHeadersVisible = False
        Me.dataGridViewData.ShowFocusCell = False
        Me.dataGridViewData.Size = New System.Drawing.Size(822, 203)
        Me.dataGridViewData.TabIndex = 6
        '
        'WeatherForecastPanel
        '
        Me.Controls.Add(Me.buttonClickMe)
        Me.Controls.Add(Me.comboBoxNumbeFetch)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.dataGridViewData)
        Me.Name = "WeatherForecastPanel"
        Me.Size = New System.Drawing.Size(857, 405)
        CType(Me.dataGridViewData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents buttonClickMe As Wisej.Web.Button
    Private WithEvents comboBoxNumbeFetch As Wisej.Web.ComboBox
    Private WithEvents label2 As Wisej.Web.Label
    Private WithEvents label1 As Wisej.Web.Label
    Private WithEvents dataGridViewData As Wisej.Web.DataGridView
End Class
