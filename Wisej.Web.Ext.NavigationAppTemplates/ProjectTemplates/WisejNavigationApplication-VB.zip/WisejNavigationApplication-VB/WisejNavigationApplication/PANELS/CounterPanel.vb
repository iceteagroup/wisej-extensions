﻿Imports System
Imports $safeprojectname$.Controls
Imports Wisej.Web
''' <summary>
''' Represents a reusable control for hosting counters.
''' </summary>
Public Class CounterPanel

    Private currentCount As Integer
    Private Sub buttonClickMe_Click(sender As Object, e As EventArgs) Handles buttonClickMe.Click
        Me.currentCount = Me.currentCount + 1
        Me.labelCurrentCount.Text = $"Current count: {currentCount}"

    End Sub

    Private Sub countersPanel_ToolClick(sender As Object, e As ToolClickEventArgs) Handles countersPanel.ToolClick
        Dim container = CType(sender, Panel)

        Select Case e.Tool.Name
            Case "Add"
                container.Controls.Add(New Counter())

            Case "Remove"
                If (container.Controls.Count > 0) Then
                    container.Controls(container.Controls.Count - 1).Dispose()
                End If
        End Select
    End Sub
End Class
