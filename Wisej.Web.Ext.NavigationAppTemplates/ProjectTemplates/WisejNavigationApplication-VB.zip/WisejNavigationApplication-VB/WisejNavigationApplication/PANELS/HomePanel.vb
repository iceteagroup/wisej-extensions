﻿Imports System
Imports Wisej.Web

''' <summary>
''' Represents a reusable control for hosting information.
''' </summary>
Public Class HomePanel

End Class
