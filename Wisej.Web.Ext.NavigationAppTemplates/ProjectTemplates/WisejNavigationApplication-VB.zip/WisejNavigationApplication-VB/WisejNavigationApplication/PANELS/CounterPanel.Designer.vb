﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CounterPanel
    Inherits Wisej.Web.UserControl

    'CounterPanel overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Wisej Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Wisej Designer
    'It can be modified using the Wisej Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Dim ComponentTool1 As Wisej.Web.ComponentTool = New Wisej.Web.ComponentTool()
        Dim ComponentTool2 As Wisej.Web.ComponentTool = New Wisej.Web.ComponentTool()
        Me.countersPanel = New Wisej.Web.FlowLayoutPanel()
        Me.buttonClickMe = New Wisej.Web.Button()
        Me.labelCurrentCount = New Wisej.Web.Label()
        Me.label1 = New Wisej.Web.Label()
        Me.SuspendLayout()
        '
        'countersPanel
        '
        Me.countersPanel.Anchor = CType((((Wisej.Web.AnchorStyles.Top Or Wisej.Web.AnchorStyles.Bottom) _
            Or Wisej.Web.AnchorStyles.Left) _
            Or Wisej.Web.AnchorStyles.Right), Wisej.Web.AnchorStyles)
        Me.countersPanel.AutoScroll = True
        Me.countersPanel.HeaderBackColor = System.Drawing.Color.Transparent
        Me.countersPanel.HeaderForeColor = System.Drawing.Color.Black
        Me.countersPanel.HeaderSize = 42
        Me.countersPanel.Location = New System.Drawing.Point(17, 202)
        Me.countersPanel.Name = "countersPanel"
        Me.countersPanel.ShowCloseButton = False
        Me.countersPanel.ShowHeader = True
        Me.countersPanel.Size = New System.Drawing.Size(802, 164)
        Me.countersPanel.TabIndex = 11
        Me.countersPanel.Text = "Counters"
        ComponentTool1.ImageSource = "resource.wx/Wisej.Ext.BootstrapIcons/plus-circle-fill.svg?color=#43BF3F"
        ComponentTool1.Name = "Add"
        ComponentTool1.Position = Wisej.Web.LeftRightAlignment.Left
        ComponentTool2.ImageSource = "resource.wx/Wisej.Ext.BootstrapIcons/trash-fill.svg?color=#FF4700"
        ComponentTool2.Name = "Remove"
        ComponentTool2.Position = Wisej.Web.LeftRightAlignment.Left
        Me.countersPanel.Tools.AddRange(New Wisej.Web.ComponentTool() {ComponentTool1, ComponentTool2})
        '
        'buttonClickMe
        '
        Me.buttonClickMe.AppearanceKey = "button-ok"
        Me.buttonClickMe.Location = New System.Drawing.Point(17, 126)
        Me.buttonClickMe.Name = "buttonClickMe"
        Me.buttonClickMe.Repeat = True
        Me.buttonClickMe.Size = New System.Drawing.Size(125, 41)
        Me.buttonClickMe.TabIndex = 10
        Me.buttonClickMe.Text = "Click me"
        '
        'labelCurrentCount
        '
        Me.labelCurrentCount.AutoSize = True
        Me.labelCurrentCount.Location = New System.Drawing.Point(17, 81)
        Me.labelCurrentCount.Name = "labelCurrentCount"
        Me.labelCurrentCount.Size = New System.Drawing.Size(97, 18)
        Me.labelCurrentCount.TabIndex = 9
        Me.labelCurrentCount.Text = "Current count: 0"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("windowTitle", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.label1.Location = New System.Drawing.Point(17, 13)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(155, 54)
        Me.label1.TabIndex = 8
        Me.label1.Text = "Counter"
        '
        'CounterPanel
        '
        Me.Controls.Add(Me.countersPanel)
        Me.Controls.Add(Me.buttonClickMe)
        Me.Controls.Add(Me.labelCurrentCount)
        Me.Controls.Add(Me.label1)
        Me.Name = "CounterPanel"
        Me.Size = New System.Drawing.Size(836, 379)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents countersPanel As Wisej.Web.FlowLayoutPanel
    Private WithEvents buttonClickMe As Wisej.Web.Button
    Private WithEvents labelCurrentCount As Wisej.Web.Label
    Private WithEvents label1 As Wisej.Web.Label
End Class
