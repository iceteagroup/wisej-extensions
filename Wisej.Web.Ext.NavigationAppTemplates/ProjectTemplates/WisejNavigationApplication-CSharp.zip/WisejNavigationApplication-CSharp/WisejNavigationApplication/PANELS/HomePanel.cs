﻿using System;
using Wisej.Web;

namespace $safeprojectname$.Panels
{
	/// <summary>
	/// Represents a reusable control for hosting information.
	/// </summary>
	public partial class HomePanel : Wisej.Web.UserControl
	{
		public HomePanel()
		{
			InitializeComponent();
		}
	}
}
