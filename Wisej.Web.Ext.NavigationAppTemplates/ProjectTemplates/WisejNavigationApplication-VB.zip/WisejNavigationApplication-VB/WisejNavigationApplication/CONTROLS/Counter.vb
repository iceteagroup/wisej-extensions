﻿Namespace Controls
    ''' <summary>
    ''' Represents a reusable counter control.
    ''' </summary>
    Public Class Counter
        Inherits Wisej.Web.FlexLayoutPanel

        Private currentCount As Integer

        Private WithEvents labelCurrentCount As Wisej.Web.Label
        Private WithEvents buttonCount As Wisej.Web.Button

        Public Sub New()
            InitializeComponent()
        End Sub

        'NOTE: The following procedure is required by the Wisej Designer
        'It can be modified using the Wisej Designer.  
        'Do not modify it using the code editor.
        Private Sub InitializeComponent()
            Me.labelCurrentCount = New Wisej.Web.Label()
            Me.buttonCount = New Wisej.Web.Button()
            Me.SuspendLayout()
            '
            'labelCurrentCount
            '
            Me.labelCurrentCount.AutoSize = True
            Me.labelCurrentCount.Location = New System.Drawing.Point(4, 8)
            Me.labelCurrentCount.Name = "labelCurrentCount"
            Me.labelCurrentCount.Size = New System.Drawing.Size(98, 15)
            Me.labelCurrentCount.TabIndex = 9
            Me.labelCurrentCount.Text = "Current count: 0"
            '
            'buttonCount
            '
            Me.buttonCount.Location = New System.Drawing.Point(4, 42)
            Me.buttonCount.Name = "buttonCount"
            Me.buttonCount.Repeat = True
            Me.buttonCount.Size = New System.Drawing.Size(229, 41)
            Me.buttonCount.TabIndex = 10
            Me.buttonCount.Text = "Click me"
            '
            'Counter
            '
            Me.Controls.Add(Me.labelCurrentCount)
            Me.Controls.Add(Me.buttonCount)
            Me.Name = "Counter"
            Me.Size = New System.Drawing.Size(240, 89)
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

        Private Sub buttonCount_Click(sender As Object, e As EventArgs) Handles buttonCount.Click
            Increase()
        End Sub

        Public Sub Increase()
            Me.currentCount = Me.currentCount + 1
            Me.labelCurrentCount.Text = $"Current count: {currentCount}"
        End Sub
    End Class

End Namespace