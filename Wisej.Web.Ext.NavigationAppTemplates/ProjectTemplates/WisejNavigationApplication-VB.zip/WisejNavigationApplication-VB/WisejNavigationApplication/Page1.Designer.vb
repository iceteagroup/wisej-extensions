﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Page1
    Inherits Wisej.Web.Page

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Wisej Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Wisej Designer
    'It can be modified using the Wisej Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Page1))
        Me.comboBoxTheme = New Wisej.Web.ComboBox()
        Me.navigationBar = New Wisej.Web.Ext.NavigationBar.NavigationBar()
        Me.navigationBarHome = New Wisej.Web.Ext.NavigationBar.NavigationBarItem()
        Me.navigationBarCounter = New Wisej.Web.Ext.NavigationBar.NavigationBarItem()
        Me.navigationBarWeatherForecast = New Wisej.Web.Ext.NavigationBar.NavigationBarItem()
        Me.panelTop = New Wisej.Web.Panel()
        Me.linkLabelAbout = New Wisej.Web.LinkLabel()
        Me.panelMain = New Wisej.Web.FlexLayoutPanel()
        Me.animationIn = New Wisej.Web.Animation(Me.components)
        Me.menuItem1 = New Wisej.Web.MenuItem()
        Me.menuItem2 = New Wisej.Web.MenuItem()
        Me.menuItem3 = New Wisej.Web.MenuItem()
        Me.panelTop.SuspendLayout()
        Me.SuspendLayout()
        '
        'comboBoxTheme
        '
        Me.comboBoxTheme.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList
        Me.comboBoxTheme.Items.AddRange(New Object() {"Bootstrap-4", "Material-3", "Blue-1", "Blue-2", "Blue-3", "Graphite-3", "Clear-3", "Classic-2", "Clear-2", "Clear-1", "Vista-2"})
        Me.comboBoxTheme.Label.Position = Wisej.Web.LabelPosition.Left
        Me.comboBoxTheme.LabelText = "Theme"
        Me.comboBoxTheme.Location = New System.Drawing.Point(22, 16)
        Me.comboBoxTheme.Name = "comboBoxTheme"
        Me.comboBoxTheme.ResponsiveProfiles.Add(CType(resources.GetObject("comboBoxTheme.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.comboBoxTheme.Size = New System.Drawing.Size(245, 30)
        Me.comboBoxTheme.TabIndex = 1
        Me.comboBoxTheme.Text = "Bootstrap-4"
        '
        'navigationBar
        '
        Me.navigationBar.Dock = Wisej.Web.DockStyle.Left
        Me.navigationBar.Items.AddRange(New Wisej.Web.Ext.NavigationBar.NavigationBarItem() {Me.navigationBarHome, Me.navigationBarCounter, Me.navigationBarWeatherForecast})
        Me.navigationBar.Logo = "Images\wisej.png"
        Me.navigationBar.Name = "navigationBar"
        Me.navigationBar.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBar.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.navigationBar.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBar.ResponsiveProfiles1"), Wisej.Base.ResponsiveProfile))
        Me.navigationBar.ShowUser = False
        Me.navigationBar.Size = New System.Drawing.Size(70, 688)
        Me.navigationBar.TabIndex = 3
        Me.navigationBar.Text = "WisejApp"
        '
        'navigationBarHome
        '
        Me.navigationBarHome.Icon = "resource.wx/Wisej.Ext.BootstrapIcons/house-door-fill.svg"
        Me.navigationBarHome.Name = "NavigationBarItem"
        Me.navigationBarHome.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBarHome.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.navigationBarHome.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBarHome.ResponsiveProfiles1"), Wisej.Base.ResponsiveProfile))
        Me.navigationBarHome.Tag = "HomePanel"
        Me.navigationBarHome.Text = "Home"
        '
        'navigationBarCounter
        '
        Me.navigationBarCounter.Icon = "resource.wx/Wisej.Ext.BootstrapIcons/plus-square.svg"
        Me.navigationBarCounter.Name = "NavigationBarItem"
        Me.navigationBarCounter.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBarCounter.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.navigationBarCounter.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBarCounter.ResponsiveProfiles1"), Wisej.Base.ResponsiveProfile))
        Me.navigationBarCounter.Tag = "CounterPanel"
        Me.navigationBarCounter.Text = "Counter"
        '
        'navigationBarWeatherForecast
        '
        Me.navigationBarWeatherForecast.Icon = "resource.wx/Wisej.Ext.BootstrapIcons/grid-3x3.svg"
        Me.navigationBarWeatherForecast.Name = "NavigationBarItem"
        Me.navigationBarWeatherForecast.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBarWeatherForecast.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.navigationBarWeatherForecast.ResponsiveProfiles.Add(CType(resources.GetObject("navigationBarWeatherForecast.ResponsiveProfiles1"), Wisej.Base.ResponsiveProfile))
        Me.navigationBarWeatherForecast.Tag = "WeatherForecastPanel"
        Me.navigationBarWeatherForecast.Text = "Wheather Forecast"
        '
        'panelTop
        '
        Me.panelTop.BackColor = System.Drawing.Color.FromArgb(247, 247, 247)
        Me.panelTop.BorderStyle = Wisej.Web.BorderStyle.Solid
        Me.panelTop.Controls.Add(Me.comboBoxTheme)
        Me.panelTop.Controls.Add(Me.linkLabelAbout)
        Me.panelTop.Dock = Wisej.Web.DockStyle.Top
        Me.panelTop.Location = New System.Drawing.Point(70, 0)
        Me.panelTop.Name = "panelTop"
        Me.panelTop.ResponsiveProfiles.Add(CType(resources.GetObject("panelTop.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.panelTop.ResponsiveProfiles.Add(CType(resources.GetObject("panelTop.ResponsiveProfiles1"), Wisej.Base.ResponsiveProfile))
        Me.panelTop.Size = New System.Drawing.Size(1744, 58)
        Me.panelTop.TabIndex = 4
        '
        'linkLabelAbout
        '
        Me.linkLabelAbout.Anchor = Wisej.Web.AnchorStyles.Right
        Me.linkLabelAbout.AutoSize = True
        Me.linkLabelAbout.Font = New System.Drawing.Font("default", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.linkLabelAbout.Location = New System.Drawing.Point(1669, 17)
        Me.linkLabelAbout.Name = "linkLabelAbout"
        Me.linkLabelAbout.ResponsiveProfiles.Add(CType(resources.GetObject("linkLabelAbout.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.linkLabelAbout.ResponsiveProfiles.Add(CType(resources.GetObject("linkLabelAbout.ResponsiveProfiles1"), Wisej.Base.ResponsiveProfile))
        Me.linkLabelAbout.Size = New System.Drawing.Size(48, 22)
        Me.linkLabelAbout.TabIndex = 0
        Me.linkLabelAbout.Text = "About"
        '
        'panelMain
        '
        Me.panelMain.Dock = Wisej.Web.DockStyle.Fill
        Me.panelMain.Location = New System.Drawing.Point(0, 0)
        Me.panelMain.Name = "panelMain"
        Me.panelMain.ResponsiveProfiles.Add(CType(resources.GetObject("panelMain.ResponsiveProfiles"), Wisej.Base.ResponsiveProfile))
        Me.panelMain.ResponsiveProfiles.Add(CType(resources.GetObject("panelMain.ResponsiveProfiles1"), Wisej.Base.ResponsiveProfile))
        Me.panelMain.Size = New System.Drawing.Size(1814, 688)
        Me.panelMain.TabIndex = 5
        '
        'menuItem1
        '
        Me.menuItem1.Index = -1
        Me.menuItem1.MenuItems.AddRange(New Wisej.Web.MenuItem() {Me.menuItem2, Me.menuItem3})
        Me.menuItem1.Name = "menuItem1"
        Me.menuItem1.Text = "menuItem1"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 0
        Me.menuItem2.Name = "menuItem2"
        Me.menuItem2.Text = "menuItem2"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 1
        Me.menuItem3.Name = "menuItem3"
        Me.menuItem3.Text = "menuItem3"
        '
        'Page1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 19.0!)
        Me.AutoScaleMode = Wisej.Web.AutoScaleMode.Font
        Me.Controls.Add(Me.panelMain)
        Me.Controls.Add(Me.panelTop)
        Me.Controls.Add(Me.navigationBar)
        Me.Name = "Page1"
        Me.Size = New System.Drawing.Size(1814, 688)
        Me.panelTop.ResumeLayout(False)
        Me.panelTop.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents comboBoxTheme As Wisej.Web.ComboBox
    Private WithEvents navigationBar As Wisej.Web.Ext.NavigationBar.NavigationBar
    Private WithEvents navigationBarHome As Wisej.Web.Ext.NavigationBar.NavigationBarItem
    Private WithEvents navigationBarCounter As Wisej.Web.Ext.NavigationBar.NavigationBarItem
    Private WithEvents navigationBarWeatherForecast As Wisej.Web.Ext.NavigationBar.NavigationBarItem
    Private WithEvents panelTop As Wisej.Web.Panel
    Private WithEvents linkLabelAbout As Wisej.Web.LinkLabel
    Private WithEvents panelMain As Wisej.Web.FlexLayoutPanel
    Private WithEvents animationIn As Wisej.Web.Animation
    Private WithEvents menuItem1 As Wisej.Web.MenuItem
    Private WithEvents menuItem2 As Wisej.Web.MenuItem
    Private WithEvents menuItem3 As Wisej.Web.MenuItem
End Class
