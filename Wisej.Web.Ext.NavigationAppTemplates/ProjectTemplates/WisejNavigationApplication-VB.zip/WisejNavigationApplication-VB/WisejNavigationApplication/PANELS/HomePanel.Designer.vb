﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HomePanel
    Inherits Wisej.Web.UserControl

    'HomePanel overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Wisej Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Wisej Designer
    'It can be modified using the Wisej Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.label2 = New Wisej.Web.Label()
        Me.label1 = New Wisej.Web.Label()
        Me.surveyPrompt1 = New Controls.SurveyPrompt()
        Me.SuspendLayout()
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(9, 84)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(159, 18)
        Me.label2.TabIndex = 7
        Me.label2.Text = "Welcome to your new app."
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("windowTitle", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.label1.Location = New System.Drawing.Point(9, 10)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(256, 54)
        Me.label1.TabIndex = 6
        Me.label1.Text = "Hello, World!"
        '
        'surveyPrompt1
        '
        Me.surveyPrompt1.Anchor = CType(((Wisej.Web.AnchorStyles.Top Or Wisej.Web.AnchorStyles.Left) _
            Or Wisej.Web.AnchorStyles.Right), Wisej.Web.AnchorStyles)
        Me.surveyPrompt1.Location = New System.Drawing.Point(17, 126)
        Me.surveyPrompt1.Name = "surveyPrompt1"
        Me.surveyPrompt1.Size = New System.Drawing.Size(694, 50)
        Me.surveyPrompt1.TabIndex = 6
        Me.surveyPrompt1.Text = "How is Wisej working for you?"
        '
        'HomePanel
        '
        Me.Controls.Add(Me.surveyPrompt1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Name = "HomePanel"
        Me.Size = New System.Drawing.Size(737, 637)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents label2 As Wisej.Web.Label
    Private WithEvents label1 As Wisej.Web.Label
    Friend WithEvents surveyPrompt1 As Controls.SurveyPrompt
End Class
